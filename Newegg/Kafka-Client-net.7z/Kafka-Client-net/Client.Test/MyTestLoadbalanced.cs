﻿using B2B.Kafka.Client;
using Kafka.Client.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client.Test
{
	public class MyTestLoadbalanced : IBalancePartition
	{
		public LoadBalancedMethod LoadBalancedMethod { get; set; }

		public int GetPartition(TopicMetaData kafkaBroker = null)
		{
			return 10;
		}
	}
}
