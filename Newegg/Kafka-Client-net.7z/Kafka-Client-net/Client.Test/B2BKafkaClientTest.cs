﻿using System;
using B2B.Kafka.Client;
using B2B.Kafka.Client.Utils;
using Kafka.Client.Response;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ZooKeeperNet;
using Newegg.B2B.Kafka;

namespace Client.Test
{
	[TestClass]
	public class B2BKafkaClientTest
	{
		/// <summary>
		/// 指定Partition
		/// </summary>
		[TestMethod]
		public void TestProducer()
		{
			// string topic = "logCollection";
			string topic = "jerry_test";

			KafkaClusterConnector clusterConnector = new KafkaClusterConnector("10.16.133.104", 2225, "0");
			int responseCode = clusterConnector.Produce(topic, "Hello Kafka.Client Test 1", 0);

			Assert.AreEqual(0, responseCode);
		}

		/// <summary>
		/// 撰寫func
		/// </summary>
		[TestMethod]
		public void TestProducerBalance()
		{
			string topic = "logCollection";

			KafkaClusterConnector clusterConnector = new KafkaClusterConnector("10.16.133.104", 2181, "0");
			/* Partition Method 回傳 1 */
			Func<TopicMetaData, int> getPartition = (t) =>
			{
				// select partition policy
				return 1;
			};

			int responseCode = clusterConnector.Produce(topic, "Hello Kafka.Client Test 1", getPartition);

			Assert.AreEqual(0, responseCode);
		}

		/// <summary>
		/// 撰寫load balanced class
		/// </summary>
		[TestMethod]
		public void TestProducerMyBalanceMethod()
		{
			string topic = "logCollection";

			/* Partition Method 回傳 10 */
			KafkaClusterConnector clusterConnector = new KafkaClusterConnector("10.16.133.104", 2181, "0", new MyTestLoadbalanced());
			int responseCode = clusterConnector.Produce(topic, "Hello Kafka.Client Test 2");

			Assert.AreEqual(0, responseCode);
		}

		/// <summary>
		/// Meta data
		/// </summary>
		[TestMethod]
		public void TestPartitionMetadata()
		{
			string topic = "logCollection";
			KafkaMetadataExecuter executer = new KafkaMetadataExecuter(new KafkaZkClient("10.16.133.104", 2181, new TimeSpan(0, 5, 0)));
			TopicMetaData result = executer.BuildEntityTopicMetadata(topic);

			Assert.IsNotNull(result);
			Assert.IsNotNull(result.PartitionMetadatas);
			Assert.AreEqual(topic, result.TopicName);
			Assert.AreEqual(3, result.PartitionMetadatas.Count);
		}

		/// <summary>
		/// 
		/// </summary>
		[TestMethod]
		public void TestConsumer()
		{
			string topic = "jerry_test";
			KafkaClusterConnector clusterConnector = new KafkaClusterConnector("10.16.133.104", 2225, "0", new MyTestLoadbalanced());
			var response = clusterConnector.Consumer(topic, 0, 10);

			Assert.IsNotNull(response);
		}

		/// <summary>
		/// 
		/// </summary>
		[TestMethod]
		public void TestOffsetResponse()
		{
			string topic = "jerry_test";
			KafkaClusterConnector clusterConnector = new KafkaClusterConnector("10.16.133.104", 2225, "0");

			var response = clusterConnector.GetOffsetResponse(topic);

			Assert.IsNotNull(response);
			Assert.AreNotEqual(0, response.Count);
			Assert.AreEqual(topic, response[0].TopicName);
			Assert.AreEqual(0, response[0].Error);
			Assert.AreEqual(KafkaExceptionType.Success, response[0].ErrorType);
		}
	}
}
