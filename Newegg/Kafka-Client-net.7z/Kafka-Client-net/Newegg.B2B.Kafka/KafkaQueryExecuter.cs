﻿using B2B.Kafka.Client.KafkaException;
using B2B.Kafka.Client.Model;
using B2B.Kafka.Client.Utils;
using Kafka.Client;
using Kafka.Client.Request;
using Kafka.Client.Response;
using Newegg.B2B.Kafka.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2B.Kafka.Client
{
	public class KafkaQueryExecuter
	{
		private int DefaultCorrelationId = 0;

		public short Producer(IKafkaConnector connector, string topicName, int partitionId, string message, string clientId)
		{
			var messageByte = Encoding.UTF8.GetBytes(message);

			ProduceResponse response = connector.Produce(DefaultCorrelationId, clientId, 3000, topicName, partitionId, messageByte);
			return response.ErrorCode(topicName, 0);
		}

		public KafkaFetchResponse Fetch(Connector connector, string topicName, int partitionId, long offset, int defaultCorrelationId, string clientId)
		{
			var kafkaResponse = new KafkaFetchResponse
			{
				ErrorCode = -1,
				MessageCollection = new List<KafkaMessage>()
			};

			FetchRequest fetchRequest = new FetchRequest(defaultCorrelationId, clientId);
			fetchRequest.AddTopic(topicName, partitionId, offset, 1024 * 100);

			FetchResponse fetchResponse = connector.Fetch(fetchRequest);
			foreach (var fetchTopic in fetchResponse.Topics)
			{
				foreach (var fetchPartition in fetchTopic.Partitions)
				{
					kafkaResponse.ErrorCode = fetchPartition.ErrorCode;
					if (fetchPartition.MessageSets == null)
						return kafkaResponse;

					foreach (var messageSet in fetchPartition.MessageSets.Where(msg=>msg.MessageSize > 0))
					{
						var kafkaMessage = new KafkaMessage();
						kafkaMessage.PartitionId = fetchPartition.PartitionId;
						kafkaMessage.TopicName = fetchTopic.TopicName;
						kafkaMessage.MessageData = Encoding.UTF8.GetString(messageSet.Message.Payload);
						kafkaMessage.MessageOffset = messageSet.MessageOffset;

						kafkaResponse.MessageCollection.Add(kafkaMessage);
					}
				}
			}

			return kafkaResponse;
		}

		public KafkaOffsetResponse GetOffsetResponse(Connector connector, string topicName, int partitionId, int defaultCorrelationId, string clientId)
		{
			var tmp = connector.GetOffsetResponse(topicName, OffsetRequest.LatestTime, 40, defaultCorrelationId, clientId, partitionId);
			if (tmp == null)
			{
				return new KafkaOffsetResponse
				{
					TopicName = topicName,
					PartitionId = partitionId,
					Error = -1
				};
			}

			KafkaOffsetResponse response = new KafkaOffsetResponse()
			{
				TopicName = topicName,
				PartitionId = partitionId,
				OffsetCount = tmp.Offsets(topicName, partitionId).Count,
			};

            if (response.OffsetCount == 1)
            {
                response.StartOffset = tmp.Offsets(topicName, partitionId)[0];
                response.EndOffset = tmp.Offsets(topicName, partitionId)[0];
            }
            else if(response.OffsetCount == 2 )
            {
                response.StartOffset = tmp.Offsets(topicName, partitionId)[1];
                response.EndOffset = tmp.Offsets(topicName, partitionId)[0];
            }
            else if (response.OffsetCount > 2)
            {
                response.StartOffset = tmp.Offsets(topicName, partitionId)[Convert.ToInt16(response.OffsetCount - 1)];
                response.EndOffset = tmp.Offsets(topicName, partitionId)[0];
            }
            else
            {
                response.StartOffset = -1;
                response.EndOffset = -1;
            }

			return response;
		}
	}
}
