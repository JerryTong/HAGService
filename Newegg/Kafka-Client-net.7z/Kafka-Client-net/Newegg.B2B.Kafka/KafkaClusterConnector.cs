﻿using B2B.Kafka.Client.KafkaException;
using B2B.Kafka.Client.Model;
using B2B.Kafka.Client.Utils;
using Kafka.Client;
using Kafka.Client.Request;
using Kafka.Client.Response;
using Newegg.B2B.Kafka.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2B.Kafka.Client
{
	public class KafkaClusterConnector
	{
		private readonly string m_clientId;
		private readonly IBalancePartition loadBalancedPartition;
		private readonly int defaultRetryCount = 1;
		private KafkaMetadataExecuter kafkaMetadataExecuter;
		private KafkaQueryExecuter kafkaQueryExecuter;

		/// <summary>
		/// topic diet.
		/// </summary>
		private Dictionary<string, TopicMetaData> topicMetaDatas = new Dictionary<string, TopicMetaData>();

		/// <summary>
		/// kafka cluster connector.
		/// </summary>
		private Dictionary<int, Connector> kafkaConnectors = new Dictionary<int, Connector>();

		/// <summary>
		/// balance Method.
		/// </summary>
		public LoadBalancedMethod LoadBalancedMethod
		{
			get { return loadBalancedPartition.LoadBalancedMethod; }
			set { loadBalancedPartition.LoadBalancedMethod = value; }
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="zkAdderss"></param>
		/// <param name="zkPort"></param>
		/// <param name="clientId"></param>
		public KafkaClusterConnector(string zkAdderss, int zkPort, string clientId)
		{
			m_clientId = clientId;

			loadBalancedPartition = new LoadBalancedPartition();
			kafkaMetadataExecuter = new KafkaMetadataExecuter(new KafkaZkClient(zkAdderss, zkPort, new TimeSpan(0, 5, 0)));
			kafkaQueryExecuter = new KafkaQueryExecuter();
		}

		/// <summary>
		/// Impletement balance partition policy
		/// </summary>
		/// <param name="zkAdderss"></param>
		/// <param name="zkPort"></param>
		/// <param name="clientId"></param>
		/// <param name="balance"></param>
		public KafkaClusterConnector(string zkAdderss, int zkPort, string clientId, IBalancePartition balance)
		{
			m_clientId = clientId;
			loadBalancedPartition = balance;

			kafkaMetadataExecuter = new KafkaMetadataExecuter(new KafkaZkClient(zkAdderss, zkPort, new TimeSpan(0, 5, 0)));
			kafkaQueryExecuter = new KafkaQueryExecuter();
		}

		/// <summary>
		/// Register Topic.
		/// </summary>
		/// <param name="topic"></param>
		/// <returns></returns>
		public bool RegisterTopic(string topic)
		{
			if (!topicMetaDatas.ContainsKey(topic))
			{
				topicMetaDatas.Add(topic, kafkaMetadataExecuter.BuildEntityTopicMetadata(topic));
			}

			return true;
		}

		/// <summary>
		/// Refresh Topic.
		/// </summary>
		/// <param name="topic"></param>
		/// <returns></returns>
		public bool RefreshTopic(string topic)
		{
			if (!topicMetaDatas.ContainsKey(topic))
			{
				topicMetaDatas.Add(topic, kafkaMetadataExecuter.BuildEntityTopicMetadata(topic));
				return true;
			}

			kafkaMetadataExecuter.RefreshTopicMetadata(topicMetaDatas[topic]);
			return true;
		}

		/// <summary>
		/// Partition Id 依賴於LoadBalancedMethod
		/// </summary>
		/// <param name="topic"></param>
		/// <param name="message"></param>
		/// <returns></returns>
		public int Produce(string topic, string message)
		{
			RegisterTopic(topic);

			int partition = loadBalancedPartition.GetPartition(topicMetaDatas[topic]);
			return DoRetry(() => this.Produce(topic, message, partition)
							, () => RefreshTopic(topic)
							, defaultRetryCount);
		}

		/// <summary>
		/// 自定義 balance Policy method
		/// </summary>
		/// <param name="topic"></param>
		/// <param name="message"></param>
		/// <param name="balancePolicy"></param>
		/// <returns></returns>
		public int Produce(string topic, string message, Func<TopicMetaData, int> balancePolicy)
		{
			RegisterTopic(topic);

			int partition = balancePolicy(topicMetaDatas[topic]);
			return DoRetry(() => this.Produce(topic, message, partition)
							, () => RefreshTopic(topic)
							, defaultRetryCount);
		}

		/// <summary>
		/// 直接指定Partition，這個方法不提供Retry機制。
		/// </summary>
		/// <param name="topic"></param>
		/// <param name="message"></param>
		/// <param name="partition"></param>
		/// <returns></returns>
		public int Produce(string topic, string message, int partitionId)
		{
			RegisterTopic(topic);

			var targetTopic = topicMetaDatas[topic];
			var leaderBroker = targetTopic.LeaderBroker(partitionId);

			if (!kafkaConnectors.ContainsKey(leaderBroker))
			{
				var broker = kafkaMetadataExecuter.BuildEntityBroker(leaderBroker);
				kafkaConnectors.Add(leaderBroker, new Connector(broker.Host, broker.Port));
			}

			return kafkaQueryExecuter.Producer(kafkaConnectors[leaderBroker], topic, partitionId, message, m_clientId);
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="topic"></param>
		/// <param name="partitionId"></param>
		/// <param name="offset"></param>
		/// <returns></returns>
		public KafkaFetchResponse Consumer(string topic, int partitionId, long offset)
		{
			RegisterTopic(topic);

			var targetTopic = topicMetaDatas[topic];
			var leaderBroker = targetTopic.LeaderBroker(partitionId);

			if (!kafkaConnectors.ContainsKey(leaderBroker))
			{
				var broker = kafkaMetadataExecuter.BuildEntityBroker(leaderBroker);
				kafkaConnectors.Add(leaderBroker, new Connector(broker.Host, broker.Port));
			}

			return kafkaQueryExecuter.Fetch(kafkaConnectors[leaderBroker], topic, partitionId, offset, 0, m_clientId);
		}

		/// <summary>
		/// 獲取指定Topic當前的Offset信息。
		/// </summary>
		/// <param name="topic"></param>
		/// <returns></returns>
		public List<KafkaOffsetResponse> GetOffsetResponse(string topic)
		{
			RegisterTopic(topic);

			var response = new List<KafkaOffsetResponse>();

			var targetTopic = topicMetaDatas[topic];
			foreach (var partitionId in targetTopic.Partitions())
			{
				var leaderBroker = targetTopic.LeaderBroker(partitionId);
				if (!kafkaConnectors.ContainsKey(leaderBroker))
				{
					var broker = kafkaMetadataExecuter.BuildEntityBroker(leaderBroker);
					kafkaConnectors.Add(leaderBroker, new Connector(broker.Host, broker.Port));
				}

				var tmp = kafkaQueryExecuter.GetOffsetResponse(kafkaConnectors[leaderBroker], topic, partitionId, 0, m_clientId);
				if (tmp != null)
				{
					response.Add(tmp);
				}
			}

			return response;
		}

		/// <summary>
		/// Retry Action.
		/// </summary>
		/// <param name="executerAction"></param>
		/// <param name="refreshAction"></param>
		/// <param name="retryCount"></param>
		/// <returns></returns>
		private int DoRetry(Func<int> executerAction, Action refreshAction, int retryCount)
		{
			int response = -1;
			for (int retry = 0; retry < retryCount; retry++)
			{
				try
				{
					response = executerAction();
					KafkaClientErrorCode responseCode = response.ToEnum<KafkaClientErrorCode>(KafkaClientErrorCode.Unknown);
					if (responseCode == KafkaClientErrorCode.UnknownTopicOrPartition
						|| responseCode == KafkaClientErrorCode.LeaderNotAvailable
						|| responseCode == KafkaClientErrorCode.NotLeaderForPartition
						|| responseCode == KafkaClientErrorCode.BrokerNotAvailable)
					{
						throw new KafkaClientException(response);
					}

					return response;
				}
				catch (KafkaClientException kafkaEx)
				{
					refreshAction();
				}
			}

			return response;
		}
	}
}
