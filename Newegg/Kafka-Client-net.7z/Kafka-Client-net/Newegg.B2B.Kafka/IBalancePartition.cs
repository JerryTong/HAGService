﻿using Kafka.Client.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2B.Kafka.Client
{
	public interface IBalancePartition
	{
		LoadBalancedMethod LoadBalancedMethod { get; set; }

		int GetPartition(TopicMetaData kafkaBroker = null);
	}
}
