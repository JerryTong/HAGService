﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2B.Kafka.Client.Utils
{
	public static class ObjectExtension
	{
		/// <summary>
		/// Object To Int
		/// </summary>
		/// <param name="value"></param>
		/// <param name="defaultValue"></param>
		/// <returns></returns>
		public static int ToInt(this object value, int defaultValue)
		{
			if (value == null || string.IsNullOrWhiteSpace(value.ToString()))
			{
				return defaultValue;
			}

			int result;
			if (Int32.TryParse(value.ToString(), out result))
			{
				return result;
			}

			return defaultValue;
		}

		public static T ToEnum<T>(this object value, T defaultValue)
		{
			if (value == null || string.IsNullOrWhiteSpace(value.ToString()))
			{
				return defaultValue;
			}

			if (value.GetType() == typeof(int))
			{
				return (T)value;
			}

			return (T)Enum.Parse(typeof(T), value.ToString());
		}
	}
}
