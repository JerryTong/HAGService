﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace B2B.Kafka.Client.Utils
{
	public class ResponseParser
	{
		public static T Parse<T>(string json)
		{
			return JsonConvert.DeserializeObject<T>(json);
		}

		/// <summary>
		/// 轉換動態欄位。
		/// dynamicFiled參數舉例說明: "partitions":{"1":[0],"2":[0],"0":[0]}  請輸入:partition。
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="json"></param>
		/// <param name="dynamicField">Root欄位名.</param>
		/// <returns></returns>
		public static T DynamicParse<T>(string json, string dynamicField)
		{
			// Example
			// Dictionary<string, JToken> dynamic = ResponseParser.Parse<Dictionary<string, JToken>>(topicInfo);
			// Dictionary<int, List<int>> partitions = ResponseParser.Parse<Dictionary<int, List<int>>>(dynamic["partitions"].ToString());

			Dictionary<string, JToken> dynamic = ResponseParser.Parse<Dictionary<string, JToken>>(json);
			return ResponseParser.Parse<T>(dynamic[dynamicField].ToString());
		}
	}
}
