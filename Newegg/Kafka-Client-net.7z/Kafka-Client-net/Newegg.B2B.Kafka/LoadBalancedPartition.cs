﻿using Kafka.Client.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2B.Kafka.Client
{
	public class LoadBalancedPartition : IBalancePartition
	{
		private static readonly object LOCK_CHOOSE_SERVICE = new object();
		private int s_RoundRobinCursor = 0;
		
		public LoadBalancedMethod LoadBalancedMethod { get; set; }
		
		public int GetPartition(TopicMetaData kafkaTopicMeta = null)
		{
			lock (LOCK_CHOOSE_SERVICE)
			{
				int avaliableSize = kafkaTopicMeta.PartitionMetadatas.Count;

				if (avaliableSize == 0)
					return 0;

				// 測試用，暫時固定
				switch (LoadBalancedMethod.RoundRobin)
				{
					case LoadBalancedMethod.NetScaler:
					case LoadBalancedMethod.Sequential:
					case LoadBalancedMethod.RoundRobin:
					default:
						if (s_RoundRobinCursor >= avaliableSize)
						{
							s_RoundRobinCursor = 0;
						}

						try
						{
							return kafkaTopicMeta.PartitionMetadatas[s_RoundRobinCursor].PartitionId;
						}
						catch (IndexOutOfRangeException)
						{
							return kafkaTopicMeta.PartitionMetadatas.First().Value.PartitionId;
						}
						finally
						{
							s_RoundRobinCursor++;
						}
				}
			}
		}
	}

	/// <summary>
	/// 
	/// </summary>
	public enum LoadBalancedMethod
	{
		/// <summary>
		/// Load Balancing via NetScaler
		/// </summary>
		NetScaler = 0,

		/// <summary>
		/// Load Balancing by Sequential.
		/// </summary>
		Sequential = 1,

		/// <summary>
		/// Load Balancing by Round Robin.
		/// </summary>
		RoundRobin = 2
	}
}
