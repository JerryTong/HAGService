﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.B2B.Kafka
{
	public enum KafkaExceptionType
	{
		Unknown = -1,

		Success = 0,

		OffsetOutOfRange = 1,

		InvalidMessage = 2,

		UnknownTopicOrPartition = 3,

		InvalidMessageSize = 4,

		LeaderNotAvailable = 5,

		NotLeaderForPartition = 6,

		RequestTimedOut = 7,

		BrokerNotAvailable = 8,

		ReplicaNotAvailable = 9,

		MessageSizeTooLarge = 10,
	}
}
