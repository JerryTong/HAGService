﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2B.Kafka.Client.KafkaException
{
	public class KafkaClientException : ApplicationException
	{
		private string message;
		private int errorCode;

		/// <summary>
		/// Exception
		/// </summary>
		/// <param name="message"></param>
		public KafkaClientException(string message)
			: base(message)
		{
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="errorCode"></param>
		public KafkaClientException(int errorCode)
		{
			this.errorCode = errorCode;
			switch (errorCode)
			{
				case 1:
					message = "OffsetOutOfRange";
					break;
				case 2:
					message = "InvalidMessage";
					break;
				case 3:
					message = "UnknownTopicOrPartition";
					break;
				case 4:
					message = "InvalidMessageSize";
					break;
				case 5:
					message = "LeaderNotAvailable";
					break;
				case 6:
					message = "NotLeaderForPartition";
					break;
				case 7:
					message = "RequestTimedOut";
					break;
				case 8:
					message = "BrokerNotAvailable";
					break;
				case 9:
					message = "ReplicaNotAvailable";
					break;
				case 10:
					message = "MessageSizeTooLarge";
					break;

				default:
					message = "Unknown";
					break;
			}
		}
	}
}
