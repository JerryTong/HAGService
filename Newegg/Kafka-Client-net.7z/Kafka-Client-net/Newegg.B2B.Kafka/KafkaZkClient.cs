﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ZooKeeperNet;
namespace B2B.Kafka.Client
{
	public class KafkaZkClient : IKafkaZkClient, IWatcher
	{
		private ZooKeeper zKeeper;

		// zookeeper connection info
		public string ZkAddress { get; set; }
		public TimeSpan ZkSessionTimeout { get; set; }

		public KafkaZkClient(string host, int port, TimeSpan sessionTimeout)
		{
			this.ZkAddress = string.Format("{0}:{1}", host, port);
			this.ZkSessionTimeout = sessionTimeout;

			zKeeper = new ZooKeeper(this.ZkAddress, this.ZkSessionTimeout, this);
		}

		public void Process(WatchedEvent @event)
		{
			if (@event.State != KeeperState.SyncConnected)
			{
				zKeeper = new ZooKeeper(this.ZkAddress, this.ZkSessionTimeout, this);
			}
		}

		public string GetTopicMetadata(string topic)
		{
			var bytes = zKeeper.GetData(string.Format("/brokers/topics/{0}", topic), false, null);
			return Encoding.UTF8.GetString(bytes);
		}

		public string GetPartitionMetadata(string topic, int partitionId)
		{
			var bytes = zKeeper.GetData(string.Format("/brokers/topics/{0}/partitions/{1}/state", topic, partitionId), false, null);
			return Encoding.UTF8.GetString(bytes);
		}

		public string GetBrokerMetadata(int id)
		{
			var bytes = zKeeper.GetData(string.Format("/brokers/ids/{0}", id), false, null);
			return Encoding.UTF8.GetString(bytes);
		}
	}
}
