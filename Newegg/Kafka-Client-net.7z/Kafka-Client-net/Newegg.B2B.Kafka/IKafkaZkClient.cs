﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2B.Kafka.Client
{
	public interface IKafkaZkClient
	{
		string ZkAddress { get; set; }

		TimeSpan ZkSessionTimeout { get; set; }

		string GetTopicMetadata(string topic);

		string GetPartitionMetadata(string topic, int partitionId);

		string GetBrokerMetadata(int id);
	}
}
