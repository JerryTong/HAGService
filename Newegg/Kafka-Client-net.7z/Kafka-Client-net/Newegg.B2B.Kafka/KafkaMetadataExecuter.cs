﻿using B2B.Kafka.Client.Utils;
using Kafka.Client.Response;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2B.Kafka.Client
{
	public class KafkaMetadataExecuter
	{
		private IKafkaZkClient m_kafkaZkClient;

		public KafkaMetadataExecuter(IKafkaZkClient kafkaZkClient)
		{
			m_kafkaZkClient = kafkaZkClient;
		}

		/// <summary>
		/// Entity topci metadata.
		/// </summary>
		/// <param name="topicName">topic name.</param>
		/// <returns></returns>
		public TopicMetaData BuildEntityTopicMetadata(string topicName)
		{
			TopicMetaData metaData = new TopicMetaData();
			metaData.TopicName = topicName;
			metaData.PartitionMetadatas = GetPartitionMetadata(topicName);

			return metaData;
		}

		/// <summary>
		/// Entity topic metadata.
		/// </summary>
		/// <param name="topicName">topic name.</param>
		/// <returns></returns>
		public void RefreshTopicMetadata(TopicMetaData topic)
		{
			topic.PartitionMetadatas = GetPartitionMetadata(topic.TopicName);
		}

		/// <summary>
		/// Entity broker info.
		/// </summary>
		/// <param name="brokerId">kafka id.</param>
		/// <returns></returns>
		public Broker BuildEntityBroker(int brokerId)
		{
			string brokerMetadataString = m_kafkaZkClient.GetBrokerMetadata(brokerId);
			var dynamicBroker = ResponseParser.Parse<dynamic>(brokerMetadataString);

			Broker broker = new Broker();
			broker.Host = dynamicBroker.host;
			broker.Port = dynamicBroker.port;
			return broker;
		}

		/// <summary>
		/// Build Entity partition Metadata
		/// </summary>
		/// <param name="zKeeper"></param>
		/// <param name="topicName"></param>
		/// <returns></returns>
		private Dictionary<int, PartitionMetadata> GetPartitionMetadata(string topicName)
		{
			Dictionary<int, PartitionMetadata> partitionMetadata = new Dictionary<int, PartitionMetadata>();

			// 獲取指定Topic 註冊資訊
			// var topic = zKeeper.GetData("/brokers/topics/logCollection", false, null);
			// var topicInfo = Encoding.UTF8.GetString(topic);
			
			var topicInfo = m_kafkaZkClient.GetTopicMetadata(topicName);

			// parse topic json
			var partitions = ResponseParser.DynamicParse<Dictionary<int, List<int>>>(topicInfo, "partitions");

			foreach (var partition in partitions)
			{
				// get partition metadata
				// var partitionStateByte = zKeeper.GetData(string.Format("/brokers/topics/{0}/partitions/{1}/state", topicName, partition.Key), false, null);
				// var partitionStateString = Encoding.UTF8.GetString(partitionStateByte);

				var partitionStateString = m_kafkaZkClient.GetPartitionMetadata(topicName, partition.Key);

				// parse partition json
				Dictionary<string, JToken> partitionJToken = ResponseParser.Parse<Dictionary<string, JToken>>(partitionStateString);
				partitionMetadata.Add(partition.Key.ToInt(-1), new PartitionMetadata
				{
					Leader = Convert.ToInt16(partitionJToken["leader"].ToString()),
					PartitionErrorCode = 0,
					PartitionId = partition.Key.ToInt(-1),
					Irs = ResponseParser.Parse<List<int>>(partitionJToken["isr"].ToString()),
					Replicas = partition.Value.ToList()
				});
			}
			
			return partitionMetadata;
		}
	}
}
