﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.B2B.Kafka.Model
{
	public class KafkaFetchResponse
	{
		public int ErrorCode { get; set; }

		public long LastOffset { get; set; }

		public int MessageCount { get; set; }

		public List<KafkaMessage> MessageCollection { get; set; }
	}
}
