﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.B2B.Kafka.Model
{
	public class KafkaMessage
	{
		public int PartitionId { get; set; }

		public string TopicName { get; set; }

		public string MessageData { get; set; }

		public long MessageOffset { get; set; }
	}
}
