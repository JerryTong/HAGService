﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Newegg.B2B.Kafka.Model
{
	public class KafkaOffsetResponse
	{
		public string TopicName { get; set; }

		public int PartitionId { get; set; }

		public long OffsetCount { get; set; }

		public long StartOffset { get; set; }

		public long EndOffset { get; set; }

		public int Error { get; set; }

		public KafkaExceptionType ErrorType
		{
			get { return (KafkaExceptionType)this.Error; }
		}
	}
}
